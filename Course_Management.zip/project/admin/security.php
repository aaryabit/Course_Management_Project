<?php

include '../components/connect.php';

if (isset($_POST['sub1'])) {
    $em = $_POST['em'];
    $em = filter_var($em, FILTER_SANITIZE_STRING);
    $sq = $_POST['question'];
    $sq = filter_var($sq, FILTER_SANITIZE_STRING);
    $sqa = $_POST['sqa'];
    $sqa = filter_var($sqa, FILTER_SANITIZE_STRING);
    $select_user1 = $conn->prepare("SELECT * FROM `tutors` WHERE email = ? and question = ? AND answer = ? LIMIT 1");
    $select_user1->execute([$em,$sq, $sqa]);
    $row = $select_user1->fetch(PDO::FETCH_ASSOC);
    if($select_user1->rowCount() > 0){
       if (isset($_POST['sub1'])) {
         header('location:reset.php');
       }
    }else{
       $message[] = 'incorrect email, sequrity question or answer!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>StudyTube-Home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>

      <div class="form-container">
         <form action="" method="post" enctype="multipart/form-data" class="login">
         <p>Email <span>*</span></p>
      <input type="email" name="em" placeholder="Enter your email" maxlength="50" required class="box">
         <p>Select Security question<span>*</span></p>
            <select name="question" class="box" required>
               <option value="1" disabled selected>-- select security question--</option>
               <option value="2">What was the name of your childhood best friend?</option>
               <option value="3">What extracurricular activity did you enjoy the most during high school?</option>
               <option value="4">What is the name of a professor who had a significant impact on your education?</option>
               <option value="5">What subject did you enjoy the most in high school?</option>
               <option value="6">What subject did you find most challenging in high school?</option>
               <option value="7">What is the name of a college you applied to but didn't attend?</option>
               <option value="8">What is the name of a childhood hero or role model?</option>
            </select>
            <p>Your Answer <span>*</span></p>
            <input type="password" name="sqa" placeholder="Enter security question's answer" maxlength="20" required class="box">
            <input type="submit" name="sub1" value="Submit" class="btn" id="con">
         </form>
      </div>

<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>