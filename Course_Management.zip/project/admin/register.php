<?php

include '../components/connect.php';

if(isset($_POST['submit'])){

   $id = unique_id();
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $profession = $_POST['profession'];
   $profession = filter_var($profession, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $sq = $_POST['question'];
   $sq = filter_var($sq, FILTER_SANITIZE_STRING);
   $sqa = $_POST['sqa'];
   $sqa = filter_var($sqa, FILTER_SANITIZE_STRING);
   
   $image = $_FILES['image']['name'];
   $image = filter_var($image, FILTER_SANITIZE_STRING);
   $ext = pathinfo($image, PATHINFO_EXTENSION);
   $rename = unique_id().'.'.$ext;
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = '../uploaded_files/'.$rename;

   $aadhar = $_FILES['aadhar']['name'];
   $aadhar = filter_var($aadhar, FILTER_SANITIZE_STRING);
   $ext1 = pathinfo($aadhar, PATHINFO_EXTENSION);
   $rename1 = $id.'.'.$ext1;
   $image_size1 = $_FILES['aadhar']['size'];
   $image_tmp_name1 = $_FILES['aadhar']['tmp_name'];
   $image_folder1 = '../uploaded_files/aadhar/'.$rename1;

   $resume = $_FILES['resume']['name'];
   $resume = filter_var($resume, FILTER_SANITIZE_STRING);
   $ext2 = pathinfo($resume, PATHINFO_EXTENSION);
   $rename2 = $id.'.'.$ext2;
   $image_size2 = $_FILES['resume']['size'];
   $image_tmp_name2 = $_FILES['resume']['tmp_name'];
   $image_folder2 = '../uploaded_files/resume/'.$rename2;

   $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE email = ?");
   $select_tutor->execute([$email]);
   
   if($select_tutor->rowCount() > 0){
      $message[] = 'email already taken!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         $insert_tutor = $conn->prepare("INSERT INTO `tutors`(tutor_id, name, profession, email, password, image,aadhar,resume,question,answer) VALUES(?,?,?,?,?,?,?,?,?,?)");
         $insert_tutor->execute([$id, $name, $profession, $email, $cpass, $rename,$rename1,$rename2,$sq,$sqa]);
         move_uploaded_file($image_tmp_name, $image_folder);
         move_uploaded_file($image_tmp_name1, $image_folder1);
         move_uploaded_file($image_tmp_name2, $image_folder2);
         $message[] = 'new tutor registered! please login now';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body style="padding-left: 0;">

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message form">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<!-- register section starts  -->

<section class="form-container">

   <form class="register" action="" method="post" enctype="multipart/form-data">
      <h3>register new</h3>
      <div class="flex">
         <div class="col">
            <p>Full name <span>*</span></p>
            <input type="text" name="name" placeholder="Enter your name" maxlength="50" required class="box">
            <p>Profession <span>*</span></p>
            <select name="profession" class="box" required>
               <option value="" disabled selected>-- select your profession--</option>
               <option value="developer">developer</option>
               <option value="desginer">desginer</option>
               <option value="musician">musician</option>
               <option value="biologist">biologist</option>
               <option value="teacher">teacher</option>
               <option value="engineer">engineer</option>
               <option value="lawyer">lawyer</option>
               <option value="accountant">accountant</option>
               <option value="doctor">doctor</option>
               <option value="journalist">journalist</option>
               <option value="photographer">photographer</option>
            </select>
            <p>Email <span>*</span></p>
            <input type="email" name="email" placeholder="Enter your email" maxlength="50" required class="box">
            <p>Select Aadhar<span>*</span></p>
            <input type="file" name="aadhar" accept="image/*" required class="box">
         </div>
         <div class="col">
            <p>Password <span>*</span></p>
            <input type="password" name="pass" placeholder="Enter a password" maxlength="20" required class="box">
            <p>Confirm password <span>*</span></p>
            <input type="password" name="cpass" placeholder="Confirm your password" maxlength="20" required class="box">
            <p>Select profile picture <span>*</span></p>
            <input type="file" name="image" accept="image/*" required class="box">
            <p>Select Resume<span>*</span></p>
            <input type="file" name="resume" required class="box">
         </div>
      </div>
      <p>Select Security question<span>*</span></p>
            <select name="question" class="box" required>
               <option value="1" disabled selected>-- select security question--</option>
               <option value="2">What was the name of your childhood best friend?</option>
               <option value="3">What extracurricular activity did you enjoy the most during high school?</option>
               <option value="4">What is the name of a professor who had a significant impact on your education?</option>
               <option value="5">What subject did you enjoy the most in high school?</option>
               <option value="6">What subject did you find most challenging in high school?</option>
               <option value="7">What is the name of a college you applied to but didn't attend?</option>
               <option value="8">What is the name of a childhood hero or role model?</option>
            </select>
            <p>Your Answer <span>*</span></p>
            <input type="password" name="sqa" placeholder="Enter security question's answer" maxlength="20" required class="box">
      <p class="link">already have an account? <a href="login.php">login now</a></p>
      <input type="submit" name="submit" value="register now" class="btn">
   </form>

</section>

<!-- registe section ends -->

   
</body>
</html>