<?php

include '../components/connect.php';
if(isset($_GET['get_id'])){
   $playlist_id = $_GET['get_id'];
}
if (isset($_POST['action'])) { 
   switch ($_POST['action']) { 
       case 'insert': 
           insert(); 
           break;
   } 
} 

function insert() { 
   if(isset($_GET['video_id'])){
      $content_id1 = $_GET['video_id'];
  
        $add_playlist = $conn->prepare("INSERT INTO `play_con`(playlist_id, content_id1) VALUES(?,?)");
        $add_playlist->execute([$playlist_id, $content_id1]);
        $message[] = 'Video added!';
  }
   exit; 
} 
?>