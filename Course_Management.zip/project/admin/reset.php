<?php

include '../components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}
if (isset($_POST['reset_submit'])) {
   $new_pass = sha1($_POST['new_pass']);
   $new_pass = filter_var($new_pass, FILTER_SANITIZE_STRING);
   $confirm_new_pass = sha1($_POST['confirm_new_pass']);
   $confirm_new_pass = filter_var($confirm_new_pass, FILTER_SANITIZE_STRING);
          if($new_pass != $confirm_new_pass){
             $message[] = 'Confirm Password Not Matched!';
          }else{
          $confirm_new_pass = sha1($_POST['confirm_new_pass']); // Hash the new password
          $confirm_new_pass = filter_var($confirm_new_pass, FILTER_SANITIZE_STRING);
          
          // You should also validate the new password here (e.g., minimum length, complexity rules)
       
          $update_password = $conn->prepare("UPDATE `users` SET password = ? WHERE email = ?");
          if ($update_password->execute([$confirm_new_pass, $user_id])) {
             header('Location: login.php?message=success');
            exit();
          } else {
             $message[] = 'Password update failed!';
          }
          }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>StudyTube-Home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>

      <div class="form-container">
      <form action="" method="post" enctype="multipart/form-data" class="login">
            <p>New Password <span>*</span></p>
            <input type="password" name="new_pass" placeholder="Enter Your New Password" maxlength="20" class="box">
            <p>Confirm Password <span>*</span></p>
            <input type="password" name="confirm_new_pass" placeholder="Confirm Your New Password" maxlength="20" class="box">
            <input type="submit" name="reset_submit" value="Submit" class="btn" id="reset_submit">
      </form>
      </div>

<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>