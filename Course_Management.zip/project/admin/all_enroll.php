<?php
include '../components/connect.php';

if (isset($_COOKIE['tutor_id'])) {
    $tutor_id = $_COOKIE['tutor_id'];
} else {
    $tutor_id = '';
    header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">
    <style>
        /* Add these styles to your custom CSS file (admin_style.css) */

/* Style the table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    
}

/* Style the table header (th) */
table th {
    background-color: #f2f2f2;
    text-align: left;
    padding: 10px;
    font-weight: bold;
    border-bottom: 1px solid #ccc;
    font-size: 5rem;
}

/* Style the table data cells (td) */
table td {
    padding: 10px;
    border-bottom: 1px solid #ccc;
    font-size: 4rem;
}

/* Add some spacing to the last row */
table tbody tr:last-child td {
    border-bottom: none;
}

/* Add hover effect to table rows */
table tbody tr:hover {
    background-color: #f5f5f5;
}

    </style>
</head>
<body>

<?php include '../components/admin_header.php'; ?>

<!-- Create a table to display playlists and enroll numbers -->
<table>
    <thead>
        <tr>
            <th>Playlist</th>
            <th>Enroll number</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Fetch data from the database and populate the table
        $sql = "SELECT playlist.title, COALESCE(enroll_count, 0) AS enroll_number
                FROM playlist
                LEFT JOIN (
                    SELECT playlist_id, COUNT(*) AS enroll_count
                    FROM enroll
                    GROUP BY playlist_id
                ) AS enroll_counts
                ON playlist.playlist_id = enroll_counts.playlist_id
                WHERE playlist.tutor_id = ?"; // Add a WHERE clause to filter by tutor_id

        $stmt = $conn->prepare($sql);
        $stmt->execute([$tutor_id]); // Pass the tutor_id as a parameter

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $playlistTitle = $row['title'];
            $enrollNumber = $row['enroll_number'];

            echo '<tr>';
            echo '<td>' . $playlistTitle . '</td>';
            echo '<td>' . $enrollNumber . '</td>';
            echo '</tr>';
        }
        ?>
    </tbody>
</table>

</body>
</html>
