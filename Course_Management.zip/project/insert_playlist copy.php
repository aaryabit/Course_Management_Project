<?php
include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}
if(isset($_GET['get_id'])){
    $get_id = $_GET['get_id'];
 }

$message = array(); // Initialize message array

if (isset($_POST["add"])) {
   foreach ($_POST as $key => $value) {
      if (strpos($key, "video_id_") === 0) {
         $video_id = $value; // Define $video_id
         $content_id1 = $_POST["video_id_" . $video_id] ?? null; // Get content_id1 if available
         $submitted_key = "submitted_" . $video_id;

         if ($content_id1 !== null) {
            $playlist_id = $_GET['get_id'];

            // Check if the entry already exists in play_con table
            $check_entry = $conn->prepare("SELECT COUNT(*) FROM `play_con` WHERE playlist_id = ? AND content_id = ?");
            $check_entry->execute([$playlist_id, $content_id1]);
            $entry_exists = $check_entry->fetchColumn();

            if ($entry_exists == 0) {
               $id=unique_id();
               // Insert the entry if it doesn't exist
               $add_playlist = $conn->prepare("INSERT INTO `user_playlist` (user_playlist_id,playlist_id, content_id) VALUES (?,?, ?)");
               $add_playlist->execute([$id,$playlist_id, $content_id1]);
               $message[] = 'Video added to playlist';
            } else {
               $message[] = 'Video is already in the playlist';
            }
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Add Content</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="contents">

   <h1 class="heading">Add contents</h1>

   <div class="box-container">

   <?php
      $select_videos = $conn->prepare("SELECT * FROM `content` WHERE tutor_id = ? ORDER BY date DESC");
      $select_videos->execute([$tutor_id]);
      if($select_videos->rowCount() > 0){
         while($fecth_videos = $select_videos->fetch(PDO::FETCH_ASSOC)){ 
            $video_id = $fecth_videos['tutor_id'];
   ?>
      <div class="box">
         <div class="flex">
            <div><i class="fas fa-dot-circle" style="<?php if($fecth_videos['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"></i><span style="<?php if($fecth_videos['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"><?= $fecth_videos['status']; ?></span></div>
            <div><i class="fas fa-calendar"></i><span><?= $fecth_videos['date']; ?></span></div>
         </div>
         <img src="../uploaded_files/<?= $fecth_videos['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fecth_videos['title']; ?></h3>
         <?php
            $content_id1 = $_POST["video_id_" . $video_id] ?? null; // Get content_id1 if available
            $submitted_key = "submitted_" . $video_id;
         ?>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="video_id_<?= $video_id; ?>" value="<?= $video_id; ?>">
            <input type="hidden" name="submitted_<?= $video_id; ?>" value="1">
            <input type="submit" class="option-btn" name="add" value="Add">
         </form>
         <a href="view_content.php?get_id=<?= $video_id; ?>" class="btn">view content</a>
      </div>

   <?php
         }
      } else {
         echo '<p class="empty">no contents added yet!</p>';
      }
   ?>

   </div>

</section>
<script>
   
</script>
<script src="../js/admin_script.js"></script>

</body>
</html>
