<?php
include 'components/connect.php';

if (isset($_POST['content_id']) && isset($_POST['user_id']) && isset($_POST['seek_time'])) {
    $content_id = $_POST['content_id'];
    $user_id = $_POST['user_id'];
    $seek_time = $_POST['seek_time'];

    // Check if a record already exists for this content and user
    $select_us_con = $conn->prepare("SELECT * FROM `us_con` WHERE user_id = ? AND content_id = ?");
    $select_us_con->execute([$user_id, $content_id]);

    if ($select_us_con->rowCount() > 0) {
        // Update the SeekTime value
        $update_seek_time = $conn->prepare("UPDATE `us_con` SET SeekTime = ? WHERE user_id = ? AND content_id = ?");
        $update_seek_time->execute([$seek_time, $user_id, $content_id]);
    } else {
        // Insert a new record
        $insert_seek_time = $conn->prepare("INSERT INTO `us_con` (user_id, content_id, SeekTime) VALUES (?, ?, ?)");
        $insert_seek_time->execute([$user_id, $content_id, $seek_time]);
    }
}
?>
