<?php

include 'components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

$select_contents = $conn->prepare("SELECT COUNT(*) AS total_contents FROM `content`");
$select_contents->execute();
$total_contents = $select_contents->fetchColumn();

// Get the total count of records in the 'playlist' table
$select_playlists = $conn->prepare("SELECT COUNT(*) AS total_playlists FROM `playlist`");
$select_playlists->execute();
$total_playlists = $select_playlists->fetchColumn();

// Get the total count of records in the 'users' table
$select_user = $conn->prepare("SELECT COUNT(*) AS total_users FROM `users`");
$select_user->execute();
$total_users = $select_user->fetchColumn();

// Get the total count of records in the 'tutors' table
$select_tutor = $conn->prepare("SELECT COUNT(*) AS total_tutor FROM `tutors`");
$select_tutor->execute();
$total_tutor = $select_tutor->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include 'components/admin_header.php'; ?>
   
<section class="dashboard">

   <h1 class="heading">dashboard</h1>

   <div class="box-container">

      <div class="box">
         <h3>welcome!</h3>
         <a href="profile.php" class="btn">View all Teacher's</a>
      </div>

      <div class="box">
         <h3><?= $total_contents; ?></h3>
         <a><h3>Total number of videos</h3></a>
      </div>

      <div class="box">
         <h3><?= $total_playlists; ?></h3>
         <a><h3>Total number of courses</h3></a>
      </div>

      <div class="box">
         <h3><?= $total_users; ?></h3>
         <a><h3>Total number of users</h3></a>
      </div>

      <div class="box">
         <h3><?= $total_tutor; ?></h3>
         <a><h3>Total number of teachers</h3></a>
      </div>

   </div>

</section>


<script src="../js/admin_script.js"></script>

</body>
</html>