<?php
include 'components/connect.php';

if(isset($_GET['tutor_id'])){
   $tutor_id = $_GET['tutor_id'];
}else{
   $tutor_id = '';
}

if(isset($_POST['tutor_fetch'])){

   $tutor_email = $_POST['tutor_email'];
   $tutor_email = filter_var($tutor_email, FILTER_SANITIZE_STRING);
   $select_tutor = $conn->prepare('SELECT * FROM `tutors` WHERE email = ?');
   $select_tutor->execute([$tutor_email]);

   $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);
   $tutor_id = $fetch_tutor['tutor_id'];

   $count_playlists = $conn->prepare("SELECT * FROM `playlist` WHERE tutor_id = ?");
   $count_playlists->execute([$tutor_id]);
   $total_playlists = $count_playlists->rowCount();

   $count_contents = $conn->prepare("SELECT * FROM `content` WHERE tutor_id = ?");
   $count_contents->execute([$tutor_id]);
   $total_contents = $count_contents->rowCount();

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>StudyTube-Tutor's Profile</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

   <style>
      /* Add custom CSS for tabs */
      .tabs {
         display: flex;
         justify-content: center;
         margin-top: 20px;
      }

      .tab {
         cursor: pointer;
         padding: 10px 20px;
         margin: 0 10px;
         background-color: #f1f1f1;
         border-radius: 5px;
      }

      .active-tab {
         background-color: #007bff;
         color: white;
      }

      .content-section {
         display: none;
      }

      .content-section.active {
         display: block;
      }

      /* Custom CSS for the added elements */
      .box img.thumb {
    max-width: 100%;
    height: auto;
    max-height: 150px; /* Adjust the maximum height as needed */
  }

      /* Revert the CSS for content */
      .box {
         text-align: center;
         padding: 20px;
         background-color: #fff;
         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
         margin-bottom: 20px;
      }

      .box h3 {
         font-size: 18px;
         margin-top: 10px;
      }

      .box span {
         font-size: 14px;
         color: #999;
      }

      .box img.thumb {
    max-width: 100%;
    height: auto;
   
  }

      .box h3.title {
         font-size: 16px;
         margin-top: 10px;
      }

      .box a.inline-btn {
         display: inline-block;
         margin-top: 10px;
         padding: 10px 20px;
         background-color: #007bff;
         color: #fff;
         text-decoration: none;
         border-radius: 5px;
         transition: background-color 0.3s ease;
      }

      .box a.inline-btn:hover {
         background-color: #0056b3;
      }

      .empty {
         text-align: center;
         font-size: 16px;
         color: #999;
         margin-top: 20px;
      }

      /* Separate grids for videos and playlists */
      .video-grid, .playlist-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    padding: 20px;
  }

      /* Responsive grid items */
      .video-grid .box, .playlist-grid .box {
         text-align: center;
         padding: 20px;
         background-color: #fff;
         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
         margin-bottom: 20px;
      }
   </style>

</head>
<body>

<?php include 'components/admin_header.php'; ?>

<section class="courses">

   <h1 class="heading">All Courses</h1>

   <div class="playlist-grid box-container">
      <?php
      $select_courses = $conn->prepare("SELECT * FROM `content` WHERE `status` = ?");
      $select_courses->execute(['active']);
      if($select_courses->rowCount() > 0){
         while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
            $course_id = $fetch_course['content_id'];
            ?>
            
            <div class="box">
               <div class="tutor">
                  <div>
                     <span><?= $fetch_course['date']; ?></span>
                  </div>
               </div>
               <img src="../uploaded_files/<?= $fetch_course['thumb']; ?>" class="thumb" alt="">
               <h3 class="title"><?= $fetch_course['title']; ?></h3>
               <a href="view_content.php?get_id=<?= $course_id; ?>&get_id1=<?= $tutor_id; ?>" class="inline-btn">Watch Video</a>            </div>
            <?php
         }
      }else{
         echo '<p class="empty">No playlists added yet!</p>';
      }
      ?>
   </div>
</section>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>
   // JavaScript function to show the selected tab
   function showTab(tabName) {
      // Hide all content sections
      var contentSections = document.querySelectorAll('.content-section');
      contentSections.forEach(function(section) {
         section.classList.remove('active');
      });

      // Show the selected content section
      var selectedTab = document.getElementById(tabName + '-section');
      selectedTab.classList.add('active');

      // Remove 'active-tab' class from all tabs
      var tabs = document.querySelectorAll('.tab');
      tabs.forEach(function(tab) {
         tab.classList.remove('active-tab');
      });

      // Add 'active-tab' class to the selected tab
      var selectedTabBtn = document.querySelector('.tab[data-tab="' + tabName + '"]');
      selectedTabBtn.classList.add('active-tab');
   }
</script>

</body>
</html>
