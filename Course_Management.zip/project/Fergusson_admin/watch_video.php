<?php
include 'components/connect.php';

if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    $user_id = '';
}

if (isset($_GET['get_id'])) {
    $get_id = $_GET['get_id'];
} else {
    $get_id = '';
    header('location:home.php');
}

// Function to check if a user exists
function doesUserExist($conn, $user_id) {
    $stmt = $conn->prepare("SELECT COUNT(*) as user_count FROM `users` WHERE `user_id` = ?");
    $stmt->execute([$user_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['user_count'] > 0;
}

// Function to insert or update user content view record
function insertOrUpdateUsCon($conn, $user_id, $content_id, $seek_time) {
    $stmt = $conn->prepare("INSERT INTO `us_con` (user_id, content_id, videoSeen, SeekTime) 
                            VALUES (?, ?, 0, ?) 
                            ON DUPLICATE KEY UPDATE videoSeen = 0, SeekTime = ?");
    $stmt->execute([$user_id, $content_id, $seek_time, $seek_time]);
}
// Function to check if a user is enrolled in the playlist
function isUserEnrolled($conn, $user_id, $playlist_id) {
    $stmt = $conn->prepare("SELECT COUNT(*) as enroll_count FROM `enroll` WHERE `user_id` = ? AND `playlist_id` = ?");
    $stmt->execute([$user_id, $playlist_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['enroll_count'] > 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch Video</title>

    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- custom css file link -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>
<!-- Watch video section starts -->

<section class="watch-video">

    <?php
    $select_content = $conn->prepare("SELECT * FROM `content` WHERE content_id = ? AND status = ?");
    $select_content->execute([$get_id, 'active']);
    if ($select_content->rowCount() > 0) {
        while ($fetch_content = $select_content->fetch(PDO::FETCH_ASSOC)) {
            $content_id = $fetch_content['content_id'];

            $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE tutor_id = ? LIMIT 1");
            $select_tutor->execute([$fetch_content['tutor_id']]);
            $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);

            // Check if the user has already viewed this video
            if (doesUserExist($conn, $user_id)) {
                // Get the videoSeen attribute value
                $select_us_con = $conn->prepare("SELECT `videoSeen`, `SeekTime` FROM `us_con` WHERE user_id = ? AND content_id = ?");
                $select_us_con->execute([$user_id, $get_id]);
                $video_seen = 0; // Default videoSeen
                $seek_time = 0; // Default SeekTime

                if ($select_us_con->rowCount() > 0) {
                    $fetch_us_con = $select_us_con->fetch(PDO::FETCH_ASSOC);
                    $video_seen = $fetch_us_con['videoSeen'];
                    $seek_time = $fetch_us_con['SeekTime'];
                } else {
                    // Insert a new entry for this video and user
                    insertOrUpdateUsCon($conn, $user_id, $get_id, $seek_time);
                }

                // Video was previously seen, set controls and autoplay
                echo '<script>';
                echo 'document.addEventListener("DOMContentLoaded", function() {';
                echo '  const videoPlayer = document.getElementById("videoPlayer");';
                echo '  videoPlayer.currentTime = ' . $seek_time . ';';
                echo '  videoPlayer.autoplay = true;';
                echo '  videoPlayer.controls = true;';
                echo '});';
                echo '</script>';
            } else {
                // User does not exist, handle this case accordingly
            }

            $sql = "SELECT COUNT(*) as num_viewers FROM `us_con` WHERE `videoSeen` = 1 AND `videoSeen` IS NOT NULL AND `content_id` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$get_id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $num_viewers = $row['num_viewers'];

            ?>
            <?php
            if ($user_id != "") {
                ?>
                <div class="video-details">
                    <!-- Set 'autoplay' and 'controls' attributes conditionally -->
                    <video id="videoPlayer" src="uploaded_files/<?= $fetch_content['video']; ?>" class="video" poster="uploaded_files/<?= $fetch_content['thumb']; ?>"
                        <?php
                        if ($video_seen == 1) {
                            echo 'controls';
                        }
                        ?>
                        autoplay controlsList="nodownload">
                    </video>

                    <div class="info">
                        <p><i class="fas fa-calendar"></i><span><?= $fetch_content['date']; ?></span></p>
                        <p><img src="images/view.png"><span><?= $num_viewers ?></span></p>
                    </div>
                    <div class="tutor">
                        <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
                        <div>
                            <h3><?= $fetch_tutor['name']; ?></h3>
                            <span><?= $fetch_tutor['profession']; ?></span>
                        </div>
                    </div>
                    <div class="description"><p><?= $fetch_content['description']; ?></p></div>
                </div>
        </section>
        <?php
    } else {
        echo '<p class="empty">Please Login In!</p>';
    }
    ?>
    <?php
            }
        } else {
            echo '<p class="empty">No videos added yet!</p>';
        }
    ?>

    <!-- Watch video section ends -->

    <!-- custom js file link -->
    <script src="js/script.js"></script>

    <script>
  const videoPlayer = document.getElementById('videoPlayer');
let videoPausedByVisibilityChange = false;

const handleVisibilityChange = () => {
   if (document.hidden) {
      // Page is not visible, pause the video
      if (!videoPlayer.paused) {
         videoPlayer.pause();
         videoPausedByVisibilityChange = true;
      }
   } else {
      // Page is visible, resume the video if it was paused by visibility change
      if (videoPausedByVisibilityChange) {
         videoPlayer.play();
         videoPausedByVisibilityChange = false;
      }
   }
};

// Listen for the visibilitychange event
document.addEventListener('visibilitychange', handleVisibilityChange);

// Additionally, you can listen for the blur and focus events on the window
// to handle cases where the user switches to a different tab
window.addEventListener('blur', () => {
   if (!videoPlayer.paused) {
      videoPlayer.pause();
      videoPausedByVisibilityChange = true;
   }
});

window.addEventListener('focus', () => {
   if (videoPausedByVisibilityChange) {
      videoPlayer.play();
      videoPausedByVisibilityChange = false;
   }
});
   </script>
</body>
</html>

