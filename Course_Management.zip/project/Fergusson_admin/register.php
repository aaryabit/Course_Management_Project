<?php

include '../components/connect.php';

if(isset($_POST['submit'])){

   $id = unique_id();
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);


   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $sq = $_POST['question'];
   $sq = filter_var($sq, FILTER_SANITIZE_STRING);
   $sqa = $_POST['sqa'];
   $sqa = filter_var($sqa, FILTER_SANITIZE_STRING);
   

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE email = ?");
   $select_admin->execute([$email]);
   
   if($select_admin->rowCount() > 0){
      $message[] = 'email already taken!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm passowrd not matched!';
      }else{
         $insert_admin = $conn->prepare("INSERT INTO `admin`(id, name, email, password, question,answer) VALUES(?,?,?,?,?,?)");
         $insert_admin->execute([$id, $name, $email, $cpass, $sq,$sqa]);
         $message[] = 'New Admin registered! please login now';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body style="padding-left: 0;">

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message form">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<!-- register section starts  -->

<section class="form-container">

   <form class="register" action="" method="post" enctype="multipart/form-data">
      <h3>register new</h3>
      <div class="flex">
         <div class="col">
            <p>Full name <span>*</span></p>
            <input type="text" name="name" placeholder="Enter your name" maxlength="50" required class="box">
            
            <p>Email <span>*</span></p>
            <input type="email" name="email" placeholder="Enter your email" maxlength="50" required class="box">

         </div>
         <div class="col">
            <p>Password <span>*</span></p>
            <input type="password" name="pass" placeholder="Enter a password" maxlength="20" required class="box">
            <p>Confirm password <span>*</span></p>
            <input type="password" name="cpass" placeholder="Confirm your password" maxlength="20" required class="box">
           
         </div>
      </div>
      <p>Select Security question<span>*</span></p>
            <select name="question" class="box" required>
               <option value="1" disabled selected>-- select security question--</option>
               <option value="2">What was the name of your childhood best friend?</option>
               <option value="3">What extracurricular activity did you enjoy the most during high school?</option>
               <option value="4">What is the name of a professor who had a significant impact on your education?</option>
               <option value="5">What subject did you enjoy the most in high school?</option>
               <option value="6">What subject did you find most challenging in high school?</option>
               <option value="7">What is the name of a college you applied to but didn't attend?</option>
               <option value="8">What is the name of a childhood hero or role model?</option>
            </select>
            <p>Your Answer <span>*</span></p>
            <input type="password" name="sqa" placeholder="Enter security question's answer" maxlength="20" required class="box">
      <p class="link">already have an account? <a href="login.php">login now</a></p>
      <input type="submit" name="submit" value="register now" class="btn">
   </form>

</section>

<!-- registe section ends -->

   
</body>
</html>