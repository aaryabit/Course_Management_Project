<?php
include '../components/connect.php';

if (!isset($_COOKIE['tutor_id'])) {
    header('location:login.php');
    exit(); // Make sure to exit after redirecting
}

// Handle the action when "Accept" or "Reject" is clicked
if (isset($_GET['action']) && isset($_GET['tutor_id'])) {
    $action = $_GET['action'];
    $tutor_id = $_GET['tutor_id'];

    if ($action === 'accept') {
        // Update the tutor's status to 'Accept' in the 'tutors' table
        $update_status = $conn->prepare("UPDATE `tutors` SET status = 'Accept' WHERE tutor_id = ?");
        $update_status->execute([$tutor_id]);
    } elseif ($action === 'reject') {
        // Update the tutor's status to 'Reject' in the 'tutors' table
        $update_status = $conn->prepare("UPDATE `tutors` SET status = 'Reject' WHERE tutor_id = ?");
        $update_status->execute([$tutor_id]);
    }

}

$select_tutors = $conn->prepare("SELECT tutor_id, image, name, aadhar, resume, status FROM `tutors`");
$select_tutors->execute();
$tutors = $select_tutors->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Approve Tutors</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include 'components/admin_header.php'; ?>

<section class="tutor-profile" style="min-height: calc(100vh - 19rem);"> 

   <h1 class="heading">Teacher profile details</h1>

   <div class="details">
      <?php foreach ($tutors as $tutor) : ?>
         <div class="tutor">
            <img src="../uploaded_files/<?= $tutor['image']; ?>" target="_blank"></img>
            <h3><?= $tutor['name']; ?></h3>
            <span>Status: <?= $tutor['status']; ?></span>
            <a href="?action=accept&tutor_id=<?= $tutor['tutor_id']; ?>" class="inline-btn accept-reject">Accept</a>
            <a href="?action=reject&tutor_id=<?= $tutor['tutor_id']; ?>" class="inline-btn accept-reject">Reject</a>
            <a href="../uploaded_files/aadhar/<?= $tutor['aadhar']; ?>" class="inline-btn" target="_blank">View Aadhar</a>
            <a href="../uploaded_files/resume/<?= $tutor['resume']; ?>" class="inline-btn" target="_blank">View Resume</a>
         </div>
      <?php endforeach; ?>
   </div>

</section>

<script src="../js/admin_script.js"></script>

<script>
// Refresh the page after clicking "Accept" or "Reject"
const acceptRejectLinks = document.querySelectorAll('.accept-reject');
acceptRejectLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        location.reload(); // Refresh the page
    });
});
</script>

</body>
</html>
