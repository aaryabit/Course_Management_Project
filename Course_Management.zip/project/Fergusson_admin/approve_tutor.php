
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Approved Tutor</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include '../Fergusson_admin/components/admin_header.php'; ?>

<!-- courses section starts  -->
<section class="approve_tutor">



   <h1 class="heading">Teacher's Profile Approved</h1>
    <a href ="dashboard.php">Back to the dasboard</a>


<!-- courses section ends -->
<!-- custom js file link  -->

</section>
<script src="js/script.js"></script>
   
</body>
</html>