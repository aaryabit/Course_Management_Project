-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2023 at 06:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `question` varchar(50) NOT NULL,
  `answer` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `question`, `answer`) VALUES
('wdtCIc5SNT2EfJd57wcg', 'b', 'b@gmail.com', 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98', '2', 'raj');

-- --------------------------------------------------------

--
-- Table structure for table `bookmark`
--

CREATE TABLE `bookmark` (
  `user_id` varchar(20) NOT NULL,
  `playlist_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `content_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `video` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` varchar(10) NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`content_id`, `tutor_id`, `title`, `description`, `video`, `thumb`, `date`, `status`) VALUES
('fHgawBnY4GtsxKZdrBUM', 'w9qOhjG2M0wHZVvTA0WJ', 's', 'ss', '8jkauZLcCFcMFWNReI55.mp4', 'W5eIztGb8suvOQGWErHT.png', '2023-09-04', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `user_id` varchar(20) NOT NULL,
  `playlist_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `playlist`
--

CREATE TABLE `playlist` (
  `playlist_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `playlist`
--

INSERT INTO `playlist` (`playlist_id`, `tutor_id`, `title`, `description`, `thumb`, `date`, `status`) VALUES
('nJIZPzu3uTFktUyAwMYo', 'w9qOhjG2M0wHZVvTA0WJ', 's', 's', 'OsytDGRPmxrmFCcCqSL9.png', '2023-09-04', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `play_con`
--

CREATE TABLE `play_con` (
  `playlist_id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `play_con`
--

INSERT INTO `play_con` (`playlist_id`, `content_id`) VALUES
('nJIZPzu3uTFktUyAwMYo', 'fHgawBnY4GtsxKZdrBUM'),
('nJIZPzu3uTFktUyAwMYo', 'fHgawBnY4GtsxKZdrBUM');

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `tutor_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `aadhar` varchar(100) NOT NULL,
  `resume` varchar(100) NOT NULL,
  `question` varchar(10) NOT NULL,
  `answer` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tutors`
--

INSERT INTO `tutors` (`tutor_id`, `name`, `profession`, `email`, `password`, `image`, `aadhar`, `resume`, `question`, `answer`) VALUES
('w9qOhjG2M0wHZVvTA0WJ', 't', 'biologist', 't@gmail.com', '8efd86fb78a56a5145ed7739dcb00c78581c5375', 'sIwusalATGRBJVoXsDby.png', 'w9qOhjG2M0wHZVvTA0WJ.png', 'w9qOhjG2M0wHZVvTA0WJ.png', '2', 'raj');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `question` varchar(10) NOT NULL,
  `answer` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `image`, `question`, `answer`) VALUES
('46mtbdMmEx8TvKQZ6EJ6', 'a', 'a@gmail.com', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'qyZCRLkAahCknnB9haeF.png', '2', 'raj');

-- --------------------------------------------------------

--
-- Table structure for table `user_playlist`
--

CREATE TABLE `user_playlist` (
  `user_playlist_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_playlist`
--

INSERT INTO `user_playlist` (`user_playlist_id`, `user_id`, `title`) VALUES
('9rZDZVzgrYqQqXspT3JG', '46mtbdMmEx8TvKQZ6EJ6', 'stu');

-- --------------------------------------------------------

--
-- Table structure for table `user_play_con`
--

CREATE TABLE `user_play_con` (
  `playlist_id` varchar(50) NOT NULL,
  `content_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_play_con`
--

INSERT INTO `user_play_con` (`playlist_id`, `content_id`) VALUES
('9rZDZVzgrYqQqXspT3JG', 'fHgawBnY4GtsxKZdrBUM');

-- --------------------------------------------------------

--
-- Table structure for table `us_con`
--

CREATE TABLE `us_con` (
  `user_id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL,
  `videoSeen` varchar(50) NOT NULL,
  `SeekTime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookmark`
--
ALTER TABLE `bookmark`
  ADD KEY `fk_userid` (`user_id`),
  ADD KEY `fk_userid3` (`playlist_id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`),
  ADD KEY `fk_userid2` (`tutor_id`);

--
-- Indexes for table `enroll`
--
ALTER TABLE `enroll`
  ADD KEY `fk2_userid6` (`playlist_id`),
  ADD KEY `fk_us3erid` (`user_id`);

--
-- Indexes for table `playlist`
--
ALTER TABLE `playlist`
  ADD PRIMARY KEY (`playlist_id`),
  ADD KEY `fk1_userid1` (`tutor_id`);

--
-- Indexes for table `play_con`
--
ALTER TABLE `play_con`
  ADD KEY `fk2_userid1` (`content_id`),
  ADD KEY `fk_useri4d` (`playlist_id`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`tutor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_playlist`
--
ALTER TABLE `user_playlist`
  ADD PRIMARY KEY (`user_playlist_id`),
  ADD KEY `fk3_userid3` (`user_id`);

--
-- Indexes for table `user_play_con`
--
ALTER TABLE `user_play_con`
  ADD KEY `fk2_userid45` (`content_id`),
  ADD KEY `fk2_userid46` (`playlist_id`);

--
-- Indexes for table `us_con`
--
ALTER TABLE `us_con`
  ADD KEY `fk2_playlistid` (`content_id`),
  ADD KEY `fk_userid8` (`user_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookmark`
--
ALTER TABLE `bookmark`
  ADD CONSTRAINT `fk_userid` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_userid1` FOREIGN KEY (`playlist_id`) REFERENCES `playlist` (`playlist_id`),
  ADD CONSTRAINT `fk_userid3` FOREIGN KEY (`playlist_id`) REFERENCES `playlist` (`playlist_id`);

--
-- Constraints for table `content`
--
ALTER TABLE `content`
  ADD CONSTRAINT `fk_userid2` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`tutor_id`);

--
-- Constraints for table `enroll`
--
ALTER TABLE `enroll`
  ADD CONSTRAINT `fk2_userid6` FOREIGN KEY (`playlist_id`) REFERENCES `playlist` (`playlist_id`),
  ADD CONSTRAINT `fk_us3erid` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `playlist`
--
ALTER TABLE `playlist`
  ADD CONSTRAINT `fk1_userid1` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`tutor_id`);

--
-- Constraints for table `play_con`
--
ALTER TABLE `play_con`
  ADD CONSTRAINT `fk2_userid1` FOREIGN KEY (`content_id`) REFERENCES `content` (`content_id`),
  ADD CONSTRAINT `fk3_userid` FOREIGN KEY (`playlist_id`) REFERENCES `playlist` (`playlist_id`);

--
-- Constraints for table `user_playlist`
--
ALTER TABLE `user_playlist`
  ADD CONSTRAINT `fk3_userid3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `user_play_con`
--
ALTER TABLE `user_play_con`
  ADD CONSTRAINT `fk2_userid45` FOREIGN KEY (`content_id`) REFERENCES `content` (`content_id`),
  ADD CONSTRAINT `fk2_userid46` FOREIGN KEY (`playlist_id`) REFERENCES `user_playlist` (`user_playlist_id`);

--
-- Constraints for table `us_con`
--
ALTER TABLE `us_con`
  ADD CONSTRAINT `fk2_playlistid` FOREIGN KEY (`content_id`) REFERENCES `content` (`content_id`),
  ADD CONSTRAINT `fk_userid8` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
