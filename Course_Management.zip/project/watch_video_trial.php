<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

if(isset($_GET['get_id'])){
   $get_id = $_GET['get_id'];
}else{
   $get_id = '';
   header('location:home.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>watch video</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <style>
      .container {
    position: relative;
    display: flex;
    width: max-content;
    height: max-content;
    justify-content: center;
    align-items: center;
}
.container #video {
    width: 600px;
    height: 400px;
    border-radius: 20px;
}
.container .controls {
    position: absolute;
    bottom: 40px;
    width: 100%;
    display: flex;
    justify-content: space-around;
    opacity: 0.2;
    transition: opacity 0.4s;
}
.container:hover .controls {
    opacity: 1;
}
.container .controls button {
    background: transparent;
    color: #fff;
    font-weight: bolder;
    text-shadow: 2px 1px 2px #000;
    border: none;
    cursor: pointer;
}
.container .controls .timeline {
    flex: 1;
    display: flex;
    align-items: center;
    border: none;
    border-right: 3px solid #ccc;
    border-left: 3px solid #ccc;
}
.container .controls .timeline .bar{
    background: rgb(1, 1, 65);
    height: 4px;
    flex: 1;
}
.container .controls .timeline .bar .inner{
    background: #ccc;
    width: 0%;
    height: 100%;
}
.fa {
    font-size: 20px !important;
}
   </style>

</head>
<body>

<?php include 'components/user_header.php'; ?>
<!-- watch video section starts  -->

<section class="watch-video">

<?php
   $select_content = $conn->prepare("SELECT * FROM `content` WHERE id = ? AND status = ?");
   $select_content->execute([$get_id, 'active']);
   if($select_content->rowCount() > 0){
      while($fetch_content = $select_content->fetch(PDO::FETCH_ASSOC)){
         $content_id = $fetch_content['id'];
      
         $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE id = ? LIMIT 1");
         $select_tutor->execute([$fetch_content['tutor_id']]);
         $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);

         // Check if the user has already viewed this video
         $select_us_con = $conn->prepare("SELECT * FROM `us_con` WHERE user_id1 = ? AND content_id = ?");
         $select_us_con->execute([$user_id, $get_id]);
         if($select_us_con->rowCount() == 0) {
            // Insert new record if the user hasn't viewed the video before
            $insert_us_con = $conn->prepare("INSERT INTO `us_con`(user_id1,content_id,videoSeen,SeekTime) VALUES(?,?,?,?)");
            $insert_us_con->execute([$user_id, $get_id, 0, 0]);
             // Initialize $video_seen to 0
             $video_seen = 0;

         } else {
            // Get the videoSeen attribute value
            $fetch_us_con = $select_us_con->fetch(PDO::FETCH_ASSOC);
            $video_seen = $fetch_us_con['videoSeen'];
         }
   $sql = "SELECT COUNT(*) as num_viewers FROM `us_con` WHERE `videoSeen` = 1 AND `videoSeen` IS NOT NULL AND `content_id` = ?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$get_id]);
   $row = $stmt->fetch(PDO::FETCH_ASSOC);
   $num_viewers = $row['num_viewers'];

         ?>
   <?php
   if($user_id != ""){
   ?>
   <div class="video-details">
   <div class="container">
        <video onclick="play(event)" src="https://res.cloudinary.com/codelife/video/upload/v1637805738/intro_l5ul1k.mp4" id="video"></video>
        <div class="controls">
            <button onclick="play(event)"><i class="fa fa-play"></i><i class="fa fa-pause"></i></button>
            <button onclick="rewind(event)"><i class="fa fa-fast-backward"></i></button>
            <div class="timeline">
                <div class="bar">
                    <div class="inner"></div>
                </div>
            </div>
            <button onclick="forward(event)"><i class="fa fa-fast-forward"></i></button>
            <button onclick="fullScreen(event)"><i class="fa fa-expand"></i></button>
            <button onclick="download(event)"><i class="fa fa-cloud-download"></i></button>
        </div>
    </div>
   <div class="info">
      <p><i class="fas fa-calendar"></i><span><?= $fetch_content['date']; ?></span></p>
      <p><img src="images/view.png"><span><?= $num_viewers?></span></p>
   </div>
   <div class="tutor">
      <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
      <div>
         <h3><?= $fetch_tutor['name']; ?></h3>
         <span><?= $fetch_tutor['profession']; ?></span>
      </div>
   </div>
   <div class="description"><p><?= $fetch_content['description']; ?></p></div>
</div>
<script>
const videoPlayer = document.getElementById('videoPlayer');
let videoPausedByVisibilityChange = false;

const handleVisibilityChange = () => {
   if (document.visibilityState === 'hidden') {
      if (!videoPlayer.paused) {
         videoPlayer.pause();
         videoPausedByVisibilityChange = true;
      }
   } else {
      if (videoPausedByVisibilityChange) {
         videoPlayer.play();
         videoPausedByVisibilityChange = false;
      }
   }
};

const handleWindowBlur = () => {
   if (!videoPlayer.paused) {
      videoPlayer.pause();
      videoPausedByVisibilityChange = true;
   }
};

const handleWindowFocus = () => {
   if (videoPausedByVisibilityChange) {
      videoPlayer.play();
      videoPausedByVisibilityChange = false;
   }
};

// Add event listeners for visibility change, blur, and focus
document.addEventListener('visibilitychange', handleVisibilityChange);
window.addEventListener('blur', handleWindowBlur);
window.addEventListener('focus', handleWindowFocus);

// Create an Intersection Observer to check video visibility
const observer = new IntersectionObserver(entries => {
   const entry = entries[0];
   if (!entry.isIntersecting && !videoPlayer.paused) {
      videoPlayer.pause();
      videoPausedByVisibilityChange = true;
   } else if (entry.isIntersecting && videoPausedByVisibilityChange) {
      videoPlayer.play();
      videoPausedByVisibilityChange = false;
   }
}, { threshold: 0 });

// Observe the video element
observer.observe(videoPlayer);

videoPlayer.addEventListener('ended', function() {
   fetch('mark_video_seen.php?content_id=<?= $content_id ?>')
      .then(response => response.text())
      .then(data => console.log(data))
      .catch(error => console.log(error));
   location.reload();
});
</script>

</section>
<?php
   }else{
      echo '<p class="empty">Please Login In!</p>';
   }
   ?>
   <?php
         }
      }else{
         echo '<p class="empty">no videos added yet!</p>';
      }
   ?>
   <script>
   const videoPlayer = document.getElementById('videoPlayer');
   videoPlayer.addEventListener('ended', function() {
      fetch('mark_video_seen.php?content_id=<?= $content_id ?>')
         .then(response => response.text())
         .then(data => console.log(data))
         .catch(error => console.log(error));
         location.reload();
   });
</script> 

<!-- watch video section ends -->



<!-- custom js file link  -->
<script src="js/script.js"></script>
<script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>
<script>
   const video = document.querySelector("#video")
// set the pause button to display:none by default
document.querySelector(".fa-pause").style.display = "none"
// update the progress bar
video.addEventListener("timeupdate", () => {
    let curr = (video.currentTime / video.duration) * 100
    if(video.ended){
        document.querySelector(".fa-play").style.display = "block"
        document.querySelector(".fa-pause").style.display = "none"
    }
    document.querySelector('.inner').style.width = `${curr}%`
})
// pause or play the video
const play = (e) => {
    // Condition when to play a video
    if(video.paused){
        document.querySelector(".fa-play").style.display = "none"
        document.querySelector(".fa-pause").style.display = "block"
        video.play()
    }
    else{
        document.querySelector(".fa-play").style.display = "block"
        document.querySelector(".fa-pause").style.display = "none"
        video.pause()
    }
}
// trigger fullscreen
const fullScreen = (e) => {
    e.preventDefault()
    video.requestFullscreen()
}
// download the video
const download = (e) => {
    e.preventDefault()
    let a = document.createElement('a')
    a.href = video.src 
    a.target = "_blank"
    a.download = ""
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
}
// rewind the current time
const rewind = (e) => {
    video.currentTime = video.currentTime - ((video.duration/100) * 5)
}
// forward the current time
const forward = (e) => {
    video.currentTime = video.currentTime + ((video.duration/100) * 5)
}
</script>
</body>
</html>